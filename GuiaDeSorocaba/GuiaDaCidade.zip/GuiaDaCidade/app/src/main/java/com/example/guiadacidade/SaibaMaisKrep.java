package com.example.guiadacidade;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;

public class SaibaMaisKrep extends AppCompatActivity {
    Button btnMapa, btnSite, btnTelefonar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_saiba_mais_krep);

        btnMapa = (Button)findViewById(R.id.btnVerNoMapa);
        btnSite = (Button)findViewById(R.id.btnAbrirSite);
        btnTelefonar = (Button)findViewById(R.id.btnTelefonar);

        btnMapa.setOnClickListener(v -> {
            Uri mapa = Uri.parse("https://maps.app.goo.gl/ig128Gue7kN3F2Yx9");
            Intent mapaKrep = new Intent(Intent.ACTION_VIEW, mapa);
            startActivity(mapaKrep);
        });

        btnSite.setOnClickListener(v ->{
            Uri uri = Uri.parse("https://www.ifood.com.br/delivery/sorocaba-sp/krep---santa-rosalia-jardim-santa-rosalia/2818af58-3821-4bd6-99ea-4bd16ed6a574");
            Intent siteKrep = new Intent(Intent.ACTION_VIEW,uri);
            startActivity(siteKrep);
        });

        btnTelefonar.setOnClickListener(v -> {
            Uri uri = Uri.parse("tel:1534186601");
            Intent dialIntent = new Intent(Intent.ACTION_DIAL, uri);
            startActivity(dialIntent);
        });
    }
}
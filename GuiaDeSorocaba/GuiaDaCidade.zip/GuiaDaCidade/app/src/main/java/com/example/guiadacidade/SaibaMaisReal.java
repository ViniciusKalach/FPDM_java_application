package com.example.guiadacidade;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;

public class SaibaMaisReal extends AppCompatActivity {

    Button btnMapa, btnSite, btnTelefonar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_saiba_mais_real);

        btnMapa = (Button)findViewById(R.id.btnVerNoMapa);
        btnSite = (Button)findViewById(R.id.btnAbrirSite);
        btnTelefonar = (Button)findViewById(R.id.btnTelefonar);

        btnMapa.setOnClickListener(v -> {
            Uri mapa = Uri.parse("https://maps.app.goo.gl/iAAEi1wEEiGwLF7z7");
            Intent mapaKrep = new Intent(Intent.ACTION_VIEW, mapa);
            startActivity(mapaKrep);
        });

        btnSite.setOnClickListener(v ->{
            Uri uri = Uri.parse("https://www.padariareal.com.br/");
            Intent siteKrep = new Intent(Intent.ACTION_VIEW,uri);
            startActivity(siteKrep);
        });

        btnTelefonar.setOnClickListener(v -> {
            Uri uri = Uri.parse("tel:1530001000");
            Intent dialIntent = new Intent(Intent.ACTION_DIAL, uri);
            startActivity(dialIntent);
        });
    }
}
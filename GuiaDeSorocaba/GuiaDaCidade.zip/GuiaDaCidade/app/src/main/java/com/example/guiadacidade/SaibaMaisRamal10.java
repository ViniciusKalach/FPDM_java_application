package com.example.guiadacidade;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;

import java.net.URI;

public class SaibaMaisRamal10 extends AppCompatActivity {

    private Button btnVerNoMapa;
    private Button btnSite;
    private Button btnTelefonar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_saiba_mais_ramal10);

        btnVerNoMapa = (Button) findViewById(R.id.btnVerNoMapa);
        btnSite = (Button) findViewById(R.id.btnAbrirSite);
        btnTelefonar = (Button) findViewById(R.id.btnTelefonar);

        btnVerNoMapa.setOnClickListener(view -> {
            Uri mapa = Uri.parse("https://maps.app.goo.gl/HUuH2ViwyoFbgaki9");
            Intent mapaRamal = new Intent(Intent.ACTION_VIEW, mapa);
            startActivity(mapaRamal);
        });

        btnSite.setOnClickListener(v ->{
            Uri uri = Uri.parse("http://ramal10.com.br/");
            Intent siteKrep = new Intent(Intent.ACTION_VIEW,uri);
            startActivity(siteKrep);
        });

        btnTelefonar.setOnClickListener(v -> {
            Uri uri = Uri.parse("tel:1532177126");
            Intent dialIntent = new Intent(Intent.ACTION_DIAL, uri);
            startActivity(dialIntent);
        });
    }
}
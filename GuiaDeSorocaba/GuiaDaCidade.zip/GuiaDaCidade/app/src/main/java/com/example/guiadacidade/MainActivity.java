package com.example.guiadacidade;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button btnKrep;
    private Button btnReal;
    private Button btnRamal10;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnKrep = (Button) findViewById(R.id.btnSaibaMais);
        btnReal = (Button) findViewById(R.id.btnSaibaMais1);
        btnRamal10 = (Button) findViewById(R.id.btnSaibaMais2);

        btnKrep.setOnClickListener(view -> {
            Intent SaibaMaisKrep = new Intent(this,com.example.guiadacidade.SaibaMaisKrep.class);
            startActivity(SaibaMaisKrep);
        });

        btnReal.setOnClickListener(view -> {
            Intent SaibaMaisReal = new Intent(this,com.example.guiadacidade.SaibaMaisReal.class);
            startActivity(SaibaMaisReal);
        });

        btnRamal10.setOnClickListener(view -> {
            Intent SaibaMaisRamal10 = new Intent(this,com.example.guiadacidade.SaibaMaisRamal10.class);
            startActivity(SaibaMaisRamal10);
        });
    }
}